package com.example.doorlockmain;

import java.util.ArrayList;

public class ResponseDoor {
    public int resCode;
    public String resMessage;
    public ArrayList<DoorLock> results = new ArrayList<DoorLock>();
}
