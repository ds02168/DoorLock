package com.example.doorlockmain;

import com.android.volley.RequestQueue;


//태형
//Volley 사용을 위한 큐 생성
public class AppHelper {
    public static RequestQueue requestQueue;
}
