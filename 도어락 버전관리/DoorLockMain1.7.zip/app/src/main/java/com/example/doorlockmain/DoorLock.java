package com.example.doorlockmain;

//태형
//도어락 정보를 가진 JSON객체
public class DoorLock {
    String id;
    String password;
    String address;
    int status;

}
