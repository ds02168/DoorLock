package com.example.testapp;

import java.util.ArrayList;

//태형
//서버 주고받기 위해 (안드는 사용x)
public class ResponseDoor {
    public int resCode;
    public String resMessage;
    public ArrayList<DoorLock> results = new ArrayList<DoorLock>();
}
