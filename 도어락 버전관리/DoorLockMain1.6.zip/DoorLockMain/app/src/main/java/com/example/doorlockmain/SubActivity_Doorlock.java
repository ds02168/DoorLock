package com.example.doorlockmain;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


//태형
public class SubActivity_Doorlock extends AppCompatActivity {

    /*
     * -------------------V1.0-------------------
     * 1. 메인화면과 합치기 위하여 프래그먼트로 작성
     * 2. 하단과 상단의 뷰들은 확인을 위해 임시로 생성
     * 3. 서버 클라이언트간 Log의 Tag는 "Server"로 통일
     * -------------------V1.1-------------------
     * 1. 하나의 화면으로 구성되므로 도어 프래그먼트 삭제
     * 2. 도어 프래그먼트의 기능을 SubAcitivty_DoorLock로 이전
     * -------------------V1.2-------------------
     * 1. JSON통신을 위한 클래스 생성과 외부라이브러리 Import
     * 2. (Volley,Json)
     * -------------------V1.3-------------------
     * 1. Volley를 이용한 HTTP통신을 위해 AppHelper(큐)정의, onCreate에서 인스턴스받기
     * 2. Json을 주고 받기 위해 DoorLock(데이터), ResponseDoor(통신정보)정의
     * -------------------V1.4-------------------
     * 1. 서버 상단 주소입력창으로 수정
     * 2. 안드로이드 -> PC로 서버 이전
     * 3. UI수정
     * -------------------V1.5-------------------
     * 1. 서버 서비스(서버구축시 필요로 남김),클라이언트 쓰레드,핸들러 삭제
     * 2. 안드로이드 외부의 NODE.JS서버 호출
     * -------------------V1.5-------------------
     * 1. 도어락 조작 Post방식 Request추가(서버 미구현으로 동작x)
     * 2. 조작전 서버로 부터 도어락 상태 받아오도록 수정
     * */

    //문이 열림, 닫힘, 잠김 상황을 상수로 표현
    public static final int DOOR_OPEN=1; //열린 상태
    public static final int DOOR_CLOSE=2; //닫힌 상태
    public static final int DOOR_LOCK=3; //잠긴 상태
    public static final int DOOR_NOPE=13; //문이 열린(닫히지않은) 상태에서 잠그려 할때
    public static final int DOOR_CCLOSE=22; //문이 이미 잠겨있지 않을때 풀려 할때
    public static final int DOOR_LLOCK=33; //문이 잠겨 있을때 잠그려 할때

    EditText server_edit; //서버 주소 입력창
    TextView textView2; //연결 상태 확인을 위한 텍스트뷰
    TextView userAddr; //서버 연결 상태 확인
    DoorLock doorObject; //로그인한 도어락 객체
    Gson gson = new Gson(); //JSON을 주고받기 위한 gson

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_doorlock);

        Intent intent = getIntent();
        processIntent(intent);

        //서버와 연결 하는 버튼
        Button server_link = findViewById(R.id.server_link);

        //문을 조작하는 버튼
        ImageButton door_open = findViewById(R.id.door_open);
        ImageButton door_lock = findViewById(R.id.door_lock);

        //하단의 연결 상태 확인 텍스트뷰
        textView2 = findViewById(R.id.link_status);

        //상단 서버 주소창(임시)
        server_edit = findViewById(R.id.server_edit);

        //도어락 주소 확인
        userAddr = findViewById(R.id.user_addr);

        //서버 통신 버튼
        server_link.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                request();
            }
        });

        //문 조작 버튼 Server 소켓 통신 구현
        door_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "문을 여시겠습니까?";
                requestDialog(v,message,DOOR_CLOSE);
            }
        });
        door_lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "문을 잠그시겠습니까?";
                requestDialog(v,message,DOOR_LOCK);
            }
        });

        //RequestQueue 생성
        if(AppHelper.requestQueue == null){
            AppHelper.requestQueue = Volley.newRequestQueue(getApplicationContext());
        }
    }

    //첫 화면에서 받아온 인텐트 처리하는 함수
    private void processIntent(Intent intent){
        if(intent != null){
            Snackbar.make(this.getWindow().getDecorView(),"환영합니다.",Snackbar.LENGTH_LONG).show();
        }
    }


    //서버로 부터 데이터를 받아 온다
    public void request(){
        //주소 가져오기
        String urlString = server_edit.getText().toString();
        urlString += ":18289/customer/get?id=1";

        //StringRequest생성
        StringRequest request = new StringRequest(
                Request.Method.GET,
                urlString,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response) {
                        processResponse(response);
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 -> " + error.getMessage());
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();

                return params;
            }
        };

        request.setShouldCache(false);
        AppHelper.requestQueue.add(request);
        println("요청 보냄.");
    }


    //서버로 부터 받아온 데이터를 객체로 전환
    public void processResponse(String value){
        println(value);
        doorObject = gson.fromJson(value,DoorLock.class);
        userAddr.setText(doorObject.address);
    }

    //다이얼로그 출력
    public void requestDialog(View v, String message, int door){
        String title="확인 메시지";
        String titleButtonYes = "예";
        String titleButtonNo = "아니오";
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(titleButtonYes,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialogInterface,int i){
                send(door);
            }
        });
        builder.setNegativeButton(titleButtonNo,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialogInterface,int i){ }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //도어락 조작(서버 미구현이라 동작 x)
    public void send(int door){
        //서버로 부터 도어락 상태 받아오기
        request();

        //전송할 객체 생성
        DoorLock doorSend = new DoorLock();
        doorSend.id=doorObject.id;
        doorSend.password=doorObject.password;
        doorSend.address=doorObject.address;
        doorSend.status=door;

        //JSON 문자열로 치환
        String door_value = gson.toJson(doorSend,DoorLock.class);

        //서버의 주소
        String urlStr = server_edit.getText().toString() + ":18289/";

        //POST방식으로 전송
        StringRequest request = new StringRequest(
                Request.Method.POST,
                urlStr,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 -> " + error.getMessage());
                    }
                }){

            //아직 서버 미구현으로 데이터 전송해도 의미x
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();
                params.put("door",door_value); //door라는 키에 door_value라는 값을 넣음
                return params;
            }
        };

        request.setShouldCache(false);
        AppHelper.requestQueue.add(request);
        println("문 수정 요청");
    }

    //연결 상태 로그 추가
    public void println(String data){
        textView2.append(data + "\n");
    }
}