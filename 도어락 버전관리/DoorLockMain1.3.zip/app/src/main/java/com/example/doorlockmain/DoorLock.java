package com.example.doorlockmain;

public class DoorLock {
    String Id;
    String Password;
    String Address;
    String status;

}
