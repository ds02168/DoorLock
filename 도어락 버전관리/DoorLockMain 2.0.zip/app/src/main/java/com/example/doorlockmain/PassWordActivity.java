package com.example.doorlockmain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PassWordActivity extends AppCompatActivity implements Button.OnClickListener {

    String default_pw = "1234";
    String pw_result = "";
    int passcodeNum = 0;

    TextView[] passcode = new TextView[4];

    Button[] btn = new Button[12];
    Integer[] R_id_btn = {R.id.num0, R.id.num1, R.id.num2, R.id.num3, R.id.num4,
            R.id.num5, R.id.num6, R.id.num7, R.id.num8, R.id.num9, R.id.ast, R.id.numsign};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        passcode[0] = findViewById(R.id.passcode1);
        passcode[1] = findViewById(R.id.passcode2);
        passcode[2] = findViewById(R.id.passcode3);
        passcode[3] = findViewById(R.id.passcode4);

        for(int i = 0; i < 12; i++) {
            btn[i] = (Button) findViewById(R_id_btn[i]);
        }

        for(int i = 0; i < 12; i++) {
            btn[i].setOnClickListener(this);
        }

        String s = btn[0].getText().toString();

    }

    public void onClick(View v) {
        Button inputBtn = (Button)findViewById(v.getId());

        String s = inputBtn.getText().toString();

        passcode[passcodeNum++].setText(s);

        if(passcodeNum == 4) {
            for(int i = 0; i < 4; i++) {
                pw_result += passcode[i].getText().toString();
            }
            if(pw_result.equals(default_pw)){
                Intent intent1 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent1);
            }
            else {
                Toast t = Toast.makeText(this.getApplicationContext(), "비밀번호 오류", Toast.LENGTH_SHORT);
                t.show();
            }
            passcodeNum = 0;
            pw_result = "";
            for(int i = 0; i < 4; i++) {
                passcode[i].setText("");
            }
        }
    }
}