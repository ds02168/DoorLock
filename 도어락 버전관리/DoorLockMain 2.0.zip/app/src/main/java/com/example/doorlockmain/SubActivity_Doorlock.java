package com.example.doorlockmain;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;


//태형
public class SubActivity_Doorlock extends AppCompatActivity {

    /*
     * -------------------V1.0-------------------
     * 1. 메인화면과 합치기 위하여 프래그먼트로 작성
     * 2. 하단과 상단의 뷰들은 확인을 위해 임시로 생성
     * 3. 서버 클라이언트간 Log의 Tag는 "Server"로 통일
     * -------------------V1.1-------------------
     * 1. 하나의 화면으로 구성되므로 도어 프래그먼트 삭제
     * 2. 도어 프래그먼트의 기능을 SubAcitivty_DoorLock로 이전
     * -------------------V1.2-------------------
     * 1. JSON통신을 위한 클래스 생성과 외부라이브러리 Import
     * 2. (Volley,Json)
     * -------------------V1.3-------------------
     * 1. Volley를 이용한 HTTP통신을 위해 AppHelper(큐)정의, onCreate에서 인스턴스받기
     * 2. Json을 주고 받기 위해 DoorLock(데이터), ResponseDoor(통신정보)정의
     * -------------------V1.4-------------------
     * 1. 서버 상단 주소입력창으로 수정
     * 2. 안드로이드 -> PC로 서버 이전
     * 3. UI수정
     * -------------------V1.5-------------------
     * 1. 서버 서비스(서버구축시 필요로 남김),클라이언트 쓰레드,핸들러 삭제
     * 2. 안드로이드 외부의 NODE.JS서버 호출
     * -------------------V1.6-------------------
     * 1. 도어락 조작 Post방식 Request추가(서버 미구현으로 동작x)
     * 2. 조작전 서버로 부터 도어락 상태 받아오도록 수정
     * -------------------V1.7-------------------
     * 1. 메인화면과 합침 2021.10.27
     * 2. 2개의 이미지버튼을 1개의 이미지와 버튼으로 수정
     * 3. 하단 화면에 상태 출력
     * -------------------V1.8-------------------
     * 1. 파이어베이스 연결
     * 2. UI수정(기존의 서버 연결 부분 삭제, 텍스트 뷰 변경)
     * 3. 도어락 클래스를 DTO구조로 수정
     * -------------------V1.9-------------------
     * 1. 리얼타임 데이터베이스 데이터 송,수신
     * 2. Volley RequestQueue(AppHelper.class) 삭제
     * -------------------V2.0-------------------
     * 1. 날짜 출력 추가
     * 2. 온라인/오프라인 화면 분할
     * 3. UI 텍스트 수정
     * */

    //문이 열림, 닫힘, 잠김 상황을 상수로 표현
    public static final int DOOR_OPEN=1; //열린 상태
    public static final int DOOR_CLOSE=2; //닫힌 상태
    public static final int DOOR_LOCK=3; //잠긴 상태
    public static final int DOOR_NOPE=123; //문이 열린(닫히지않은) 상태에서 잠그거나 해제하려 할때
    public static final int DOOR_CCLOSE=22; //잠금 해제 중복
    public static final int DOOR_LLOCK=33; //잠금 설정 중복


    TextView textView2; //연결 상태 확인을 위한 텍스트뷰
    TextView door_navi; //서버 연결 상태 확인
    DoorLock doorObject; //로그인한 도어락 정보를 저장한 객체
    Button doorlock_control; //조작 버튼
    ImageView doorlock_status; //상태 이미지
    String[] buttons = {"문 잠금", "문 열기","연결중...."}; //버튼 글자 저장
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //날짜 포맷

    //파이어베이스 데이터베이스 연결
    private FirebaseDatabase database = FirebaseDatabase.getInstance();

    //데이터베이스내에 도어 위치까지 레퍼런스(커서)
    private DatabaseReference databaseReference = database.getReference("Door");

    //연결상태 확인 레퍼런스
    private DatabaseReference connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_doorlock);

        //문을 조작하는 버튼과 상태를 보여주는 이미지
        doorlock_control = findViewById(R.id.doorlock_control);
        doorlock_status = findViewById(R.id.doorlock_status);

        //하단의 연결 상태 확인 텍스트뷰
        textView2 = findViewById(R.id.link_status);

        //도어락 주소 확인
        door_navi = findViewById(R.id.door_navi);

        //문 조작 버튼
        doorlock_control.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //현재 상태에 따라 다르게 요청을 보냄
                if(doorObject != null){
                    if(doorlock_control.getText().toString() == buttons[0]){
                        String message = "문을 잠그시겠습니까?";
                        requestDialog(v,message,DOOR_LOCK);
                    }else if(doorlock_control.getText().toString() == buttons[1]){
                        String message = "문을 여시겠습니까?";
                        requestDialog(v,message,DOOR_CLOSE);
                    }else if(doorlock_control.getText().toString() == buttons[2]){

                    }
                }
            }
        });

        Intent intent = getIntent();
        processIntent(intent);
    }




    //액태비티가 이미 만들어져 있을때
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        processIntent(intent);
    }


    //첫 화면에서 받아온 인텐트 처리하는 함수
    private void processIntent(Intent intent){
        if(intent != null){
            Snackbar.make(this.getWindow().getDecorView(),"환영합니다. 도어락 제어는 신중히 선택해 주세요.",Snackbar.LENGTH_LONG).show();

            //파이어 베이스에서 데이터 읽기
            readDoor();
        }
    }

    private void readDoor(){
        databaseReference.child("DoorLock").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.getValue(DoorLock.class) != null){
                    //도어락객체에 저장
                    doorObject = snapshot.getValue(DoorLock.class);
                    processRead(); //레이아웃 수정
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        connectedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean connected = snapshot.getValue(Boolean.class);
                if(connected){
                    processRead(); //레이아웃 수정
                }else{
                    disconnected(); //연결 해제시
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    //파이어베이스 부터 받아온 데이터를 기반으로 레이아웃 수정
    public void processRead(){
        Date now = new Date(); //현재시간 구하기

        //문의 상태에 따라 화면을 수정
        if(doorObject != null){
            //받아온 문 상태에 따라 다르게 출력
            doorlock_control.setEnabled(true);
            switch(doorObject.getStatus()){
                case DOOR_OPEN: //열려 있을 때
                    println("[" + format.format(now) + "] 문이 열렸습니다!");
                    door_navi.setText("도어락 상태 : 열림");
                    doorlock_status.setImageResource(R.drawable.door_open);
                    doorlock_control.setText(buttons[0]);
                    break;
                case DOOR_CLOSE: //잠금 해제
                    println("[" + format.format(now) + "] 잠금이 해제되었습니다!");
                    door_navi.setText("도어락 상태 : 닫힘");
                    doorlock_status.setImageResource(R.drawable.door_open);
                    doorlock_control.setText(buttons[0]);
                    break;
                case DOOR_NOPE: //열려 있을때 잠금해재 하거나 잠금 설정
                    println("[" + format.format(now) + "] 문을 닫아 주세요!");
                    door_navi.setText("도어락 상태 : 열림");
                    doorlock_status.setImageResource(R.drawable.door_open);
                    doorlock_control.setText(buttons[0]);
                    break;
                case DOOR_CCLOSE: //잠금 해제 중복
                    println("[" + format.format(now) + "] 이미 잠금이 해제 되어 있습니다!");
                    door_navi.setText("도어락 상태 : 닫힘");
                    doorlock_status.setImageResource(R.drawable.door_open);
                    doorlock_control.setText(buttons[0]);
                    break;
                case DOOR_LOCK: //잠금 설정
                    println("[" + format.format(now) + "] 잠금이 설정되었습니다!");
                    door_navi.setText("도어락 상태 : 잠김");
                    doorlock_status.setImageResource(R.drawable.door_lock);
                    doorlock_control.setText(buttons[1]);
                    break;
                case DOOR_LLOCK: //잠금 설정 중복
                    println("[" + format.format(now) + "] 이미 잠금이 설정 되어 있습니다!");
                    door_navi.setText("도어락 상태 : 잠김");
                    doorlock_status.setImageResource(R.drawable.door_lock);
                    doorlock_control.setText(buttons[1]);
                    break;
                default:
                    break;
            }
        }
    }

    //다이얼로그 출력
    public void requestDialog(View v, String message, int door){
        String title="확인 메시지";
        String titleButtonYes = "예";
        String titleButtonNo = "아니오";
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(titleButtonYes,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialogInterface,int i){
                writeDoor(door);
            }
        });
        builder.setNegativeButton(titleButtonNo,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialogInterface,int i){ }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //리얼타임 데이터베이스에 쓰기
    public void writeDoor(int door){
        databaseReference.child("DoorLock").child("status").setValue(door);
    }

    //접속이 끊어졌을때
    public void disconnected(){
        doorlock_control.setEnabled(false);
        doorlock_status.setImageResource(R.drawable.main_page_image);
        doorlock_control.setText(buttons[2]);
        door_navi.setText("연결을 확인중입니다...");
    }

    //연결 상태 로그 추가
    public void println(String data){
        textView2.append(data + "\n");
    }
}