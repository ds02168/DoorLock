package com.example.doorlockmain;

import com.android.volley.RequestQueue;

public class AppHelper {
    public static RequestQueue requestQueue;
}
